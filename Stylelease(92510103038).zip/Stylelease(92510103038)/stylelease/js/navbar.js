document.addEventListener('DOMContentLoaded', function(){
    var hamburger = document.querySelector('.hamburger-menu');
    var navContainer = document.querySelector('.nav-container');
    var userIcon = document.querySelector('.user-icon');
    var dropdownMenu = document.querySelector('.dropdown-menu');

    // Toggle menu
    hamburger.addEventListener('click', function(e){
        e.stopPropagation();
        if(navContainer.classList.contains('active')){
            navContainer.classList.remove('active');
            hamburger.classList.remove('active');
        }else{
            navContainer.classList.add('active');
            hamburger.classList.add('active');
        }
    });

    // Mobile dropdown toggle
    if(userIcon){
        userIcon.addEventListener('click', function(e){
            e.preventDefault();
            e.stopPropagation();
            if(dropdownMenu.style.display === 'block'){
                dropdownMenu.style.display = 'none';
            }else{
                dropdownMenu.style.display = 'block';
            }
        });
    }

    // Close everything when clicking outside
    document.addEventListener('click', function(e){
        if(!navContainer.contains(e.target) && !hamburger.contains(e.target)){
            navContainer.classList.remove('active');
            hamburger.classList.remove('active');
            dropdownMenu.style.display = 'none';
        }
    });

    // Close menu when clicking any nav link
    var links = document.querySelectorAll('.nav-links a');
    for(var i=0; i<links.length; i++){
        links[i].addEventListener('click', function(){
            navContainer.classList.remove('active');
            hamburger.classList.remove('active');
        });
    }
});

