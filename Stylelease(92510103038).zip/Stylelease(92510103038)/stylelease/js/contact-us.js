function validate(){
    var name = document.getElementById("Name").value;
    var email = document.getElementById("email").value;
    var contact = document.getElementById("contact_no").value;
    var message = document.getElementById("message").value;

    // Name validation
    if(name == ""){
        alert("Please Enter Your Name");
        return false;
    }
    if(!isNaN(name)){
        alert("Please Enter Characters Only in Name");
        return false;
    }

    // Email validation
    if(email == ""){
        alert("Please Enter Your Email");
        return false;
    }
    var emailformat = /^[a-zA-Z0-9_.\-]+@[a-zA-Z]{2,6}\.[a-z]{2,4}(\.[a-z]{0,2})?$/;
    if(emailformat.test(email)){
        // valid
    }else{
        alert("Please Enter Correct Email Format");
        return false;
    }

    // Contact validation
    if(contact == ""){
        alert("Please Enter Your Contact Number");
        return false;
    }
    if(isNaN(contact)){
        alert("Please Enter Numbers Only in Contact Number");
        return false;
    }
    if(contact.length !== 10){
        alert("Please Enter 10 Digit Contact Number");
        return false;
    }

    // Message validation
    if(message == ""){
        alert("Please Enter Your Message");
        return false;
    }
    if(message.length > 1000){
        alert("Message Cannot Exceed 1000 Characters");
        return false;
    }

    return true; 
}

// Allow only numeric input for contact number
document.addEventListener('DOMContentLoaded', function(){
    document.getElementById('contact_no').addEventListener('input', function () {
        this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10);
    });

    // Character counter for message
    document.getElementById('message').addEventListener('input', function () {
        const counter = document.querySelector('.char-counter');
        const len = this.value.length;
        counter.textContent = len + "/1000 characters";
    });
});

