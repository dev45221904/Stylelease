function validate(){
    var username = document.getElementById("username").value;
    var email    = document.getElementById("email").value;
    var number   = document.getElementById("contact_no").value;
    var gender   = document.getElementById("gender").value;
    var password = document.getElementById("password").value;

    // Name
    if(username == ""){
        document.getElementById("usr").innerHTML = "Please Enter Your Name";
        return false;
    }
    if(!isNaN(username)){
        document.getElementById("usr").innerHTML = "Please Enter Characters only";
        return false;
    }
    document.getElementById("usr").innerHTML = "";

    // Email
    if(email == ""){
        document.getElementById("eml").innerHTML = "Please Enter Your Email";
        return false;
    }
    var emailformat = /^[a-zA-Z0-9_.\-]+@[a-zA-Z]{2,6}\.[a-z]{2,4}(\.[a-z]{0,2})?$/;
    if(emailformat.test(email)){
        document.getElementById("eml").innerHTML = "";
    }else{
        document.getElementById("eml").innerHTML = "Please Enter correct email format";
        return false;
    }

    // Contact No
    if(number == ""){
        document.getElementById("nm").innerHTML = "Please Enter Your Contact number";
        return false;
    }
    if(isNaN(number)){
        document.getElementById("nm").innerHTML = "Please Enter numbers only";
        return false;
    }
    if(number.length !== 10){
        document.getElementById("nm").innerHTML = "Please Enter 10 digit number";
        return false;
    }
    document.getElementById("nm").innerHTML = "";

    // Gender
    if(gender == ""){
        document.getElementById("gnd").innerHTML = "Please Select Gender";
        return false;
    }
    document.getElementById("gnd").innerHTML = "";

    // Password (8-10 chars, 1 uppercase, 1 number, 1 special)
    if(password == ""){
        document.getElementById("pas").innerHTML = "Please Enter Your Password";
        return false;
    }
    if(password.length < 8 || password.length > 10){
        document.getElementById("pas").innerHTML = "Password length must be 8 to 10 characters";
        return false;
    }
    var passrule = /^(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,10}$/;
    if(passrule.test(password)){
        document.getElementById("pas").innerHTML = "";
    }else{
        document.getElementById("pas").innerHTML = "Include 1 uppercase, 1 number & 1 special character";
        return false;
    }

    return true; // form OK
}

// Numeric restriction already on input.
document.addEventListener('DOMContentLoaded', function(){
    document.getElementById('contact_no').addEventListener('input', function(e){
        this.value = this.value.replace(/[^0-9]/g, '').slice(0,10);
    });
});

function togglePassword(inputId) {
    var passwordInput = document.getElementById(inputId);
    var icon = passwordInput.nextElementSibling.querySelector('i');
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

