// CATEGORY MAP
const CATEGORY_MAP = {
    "1": /men\s*suits/i,
    "2": /men\s*ethnic/i,
    "3": /ethnic\s*wear\s*women/i,
    "4": /western\s*women/i
};

// === VALIDATION (Your taught style) ===
function validateFilter(){
    var search = document.getElementById("search").value;

    // empty input => show all products and clear message
    if(search.trim() == ""){
        document.getElementById("srch").innerHTML = "";
        $(".product").show();
        return false;
    }

    // check only characters/numbers
    if(!isNaN(search)){
        document.getElementById("srch").innerHTML = "Please Enter Characters Only";
        return false;
    }

    var allowed = /^[a-zA-Z0-9\s\-'.]{1,60}$/;
    if(allowed.test(search)){
        document.getElementById("srch").innerHTML = "";
        filterProducts();
    } else {
        document.getElementById("srch").innerHTML = "Please Enter Valid Search Text";
        return false;
    }

    return false; // prevent form submit
}

// === FILTER FUNCTION ===
function filterProducts() {
    const q = ($('#search').val() || '').trim().toLowerCase();
    const gender = $('#gender').val();
    const catVal = $('#category').val();

    $('.product').each(function () {
        const $card = $(this);
        const name = $card.find('h3').text().toLowerCase();
        const catText = $card.find('.category').text();

        const matchesSearch = !q || name.includes(q) || catText.toLowerCase().includes(q);
        let matchesGender = true;
        if (gender === 'Male')   matchesGender = /men|male/i.test(catText);
        if (gender === 'Female') matchesGender = /women|female/i.test(catText);

        let matchesCategory = true;
        if (catVal) {
            const re = CATEGORY_MAP[catVal];
            matchesCategory = re ? re.test(catText) : true;
        }

        $card.toggle(matchesSearch && matchesGender && matchesCategory);
    });
}

// === EVENT HANDLERS ===
$(document).ready(function() {
    $('#gender, #category').on('change', filterProducts);

    // live validation + show all when cleared
    $('#search').on('input', function(){
        if($('#search').val().trim() === ""){
            $(".product").show();
            document.getElementById("srch").innerHTML = "";
        } else {
            validateFilter();
        }
    });
});

