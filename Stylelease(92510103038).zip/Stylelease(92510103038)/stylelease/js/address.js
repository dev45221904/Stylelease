//Validation for ZIP code input
function validateZip(){
    var zip = document.getElementById("zip_code").value;
    if(zip == ""){
        document.getElementById("zerr").innerHTML = "Please Enter ZIP Code";
        return false;
    }
    if(isNaN(zip)){
        document.getElementById("zerr").innerHTML = "Please Enter Numbers Only";
        return false;
    }
    if(zip.length !== 6){
        document.getElementById("zerr").innerHTML = "ZIP Code must be 6 digits";
        return false;
    }
    document.getElementById("zerr").innerHTML = "";
}

// Allow only numeric input as typed
document.addEventListener('DOMContentLoaded', function(){
    document.getElementById('zip_code').addEventListener('input', function () {
        this.value = this.value.replace(/[^0-9]/g, '');
    });
});

