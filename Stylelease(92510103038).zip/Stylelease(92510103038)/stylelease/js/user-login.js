// === VALIDATION (Your taught method - no length check) ===
function validate(){
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    // Email validation
    if(email == ""){
        alert("Please Enter Your Email");
        return false;
    }
    var emailformat = /^[a-zA-Z0-9_.\-]+@[a-zA-Z]{2,6}\.[a-z]{2,4}(\.[a-z]{0,2})?$/;
    if(emailformat.test(email)){
        // valid
    }else{
        alert("Please Enter Correct Email Format");
        return false;
    }

    // Password validation
    if(password == ""){
        alert("Please Enter Your Password");
        return false;
    }

    return true; 
}

// Show / hide password
function togglePassword(inputId) {
    var passwordInput = document.getElementById(inputId);
    var icon = passwordInput.nextElementSibling.querySelector('i');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

