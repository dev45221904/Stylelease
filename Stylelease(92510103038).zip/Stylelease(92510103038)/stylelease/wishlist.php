<?php
include 'navbar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wishlist</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style/wishlist.css">
</head>
<body>
    
<div class="content">
    <div class="product-grid">
        <h1>Your Wishlist</h1>
        <div class="products">
            <div class="product">
                <img src="products images/bridal 1.jpg" alt="Blue Cotton T-Shirt">
                <div class="details">
                    <h3>Women Bridal Dress</h3>
                    <p class="category">Ethnic Women Wear</p>
                    <p>Rs. 350.00 per day</p>
                </div>
                <a href="#" class="view-btn">View</a>
            </div>
            <div class="product">
                <img src="products images/Maroon 1.jpeg" alt="Blue Cotton T-Shirt">
                <div class="details">
                    <h3>Blazer</h3>
                    <p class="category">Men Suits</p>
                    <p>Rs. 350.00 per day</p>
                </div>
                <a href="#" class="view-btn">View</a>
            </div>
        </div>
    </div>
</div>
<?php include 'footer.php';?>
</body>
</html>