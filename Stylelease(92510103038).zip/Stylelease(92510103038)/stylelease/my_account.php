<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - StyleLease</title>
    <link rel="icon" type="image/x-icon" href="stylelease_favicon.ico">
    <link rel="stylesheet" href="style/account.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="content">
        <h1 class="page-title">My Account</h1>

        <div class="account-container">
            <!-- Profile Section -->
            <div class="profile-section">
                <h2 class="section-title">Profile Information</h2>
                
                <div class="info-group">
                    <span class="info-label">Full Name</span>
                    <div>Pablo Escobar</div>
                </div>

                <div class="info-group">
                    <span class="info-label">Email Address</span>
                    <div>pabloescobar1@gmail.com</div>
                </div>

                <div class="info-group">
                    <span class="info-label">Contact Number</span>
                    <div>9402389767</div>
                </div>
            </div>

            <!-- Addresses Section -->
            <div class="addresses-section">
                <h2 class="section-title">Registered Addresses</h2>
                <div class="no-addresses">
                    <p>No addresses registered yet.</p>
                    <p>Add an address when placing your next order.</p>
                </div>
                
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>