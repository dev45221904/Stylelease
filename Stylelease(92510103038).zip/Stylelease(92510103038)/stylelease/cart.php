<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Cart</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="style/cart.css">
    <style>
      
    </style>
</head>
<body>
<?php
include 'navbar.php';
?>
<div class="content">
    <h1>Your Cart</h1>

   

    <form id="cartForm" action="checkout.php" method="POST">
        <div class="cart-grid">
            <div class="cart-item" id="cart-item-1">
                <div class="item-checkbox-wrapper">
                    <input type="checkbox" name="selected_items[]" value="1" class="item-checkbox" checked>
                </div>
                <img src="products images/anarkali 1.jpg" alt="Sample Item 1">
                <div class="cart-item-title">Bridal Lehenga </div>
                <div class="cart-item-details">
                    <p><strong>Size:</strong> Medium</p>
                    <p><strong>Start Date:</strong> 20-09-2025</p>
                    <p><strong>End Date:</strong> 23-09-2025</p>
                    <p><strong>Rental Days:</strong> 3</p>
                    <p class="stock-warning">2 left in stock</p>
                </div>
                <div class="quantity-controls">
                    <button type="button" class="quantity-btn minus" data-cart-id="1">-</button>
                    <input type="number" name="quantity[1]" value="1" min="1" max="2" class="quantity-input" data-cart-id="1" data-stock="2" readonly>
                    <button type="button" class="quantity-btn plus" data-cart-id="1">+</button>
                </div>
                <div class="cart-item-price">
                    Total: ₹1,200.00
                </div>
                <div class="delete-btn" data-cart-id="1">Remove</div>
            </div>
            
            <div class="cart-item" id="cart-item-2">
                <div class="item-checkbox-wrapper">
                    <input type="checkbox" name="selected_items[]" value="2" class="item-checkbox" checked>
                </div>
                <img src="products images/TShervani2.jpg" alt="Sample Item 2">
                <div class="cart-item-title">Shervani Men</div>
                <div class="cart-item-details">
                    <p><strong>Size:</strong> Large</p>
                    <p><strong>Start Date:</strong> 25-09-2025</p>
                    <p><strong>End Date:</strong> 27-09-2025</p>
                    <p><strong>Rental Days:</strong> 2</p>
                </div>
                <div class="quantity-controls">
                    <button type="button" class="quantity-btn minus" data-cart-id="2" disabled>-</button>
                    <input type="number" name="quantity[2]" value="1" min="1" max="2" class="quantity-input" data-cart-id="2" data-stock="5" readonly>
                    <button type="button" class="quantity-btn plus" data-cart-id="2">+</button>
                </div>
                <div class="cart-item-price">
                    Total: ₹800.00
                </div>
                <div class="delete-btn" data-cart-id="2">Remove</div>
            </div>
        </div>

        <div class="address-selection">
            <h2>Select Delivery Address</h2>
            <div class="address-box">
                <label>
                    <input type="radio" name="address_id" value="1" required class="address-radio">
                    <strong>Address:</strong> 123 Main Street, Apartment 4B<br>
                    <strong>Country:</strong> India<br>
                    <strong>State:</strong> Gujarat<br>
                    <strong>City:</strong> Rajkot<br>
                    <strong>Zip Code:</strong> 360001
                </label>
            </div>
            

        <div class="cart-summary">
            <p><span id="selected-count">0</span> items selected</p>
            <p>Total: <span id="cart-total">₹0.00</span></p>
            <button type="submit" class="checkout-btn" id="checkoutBtn" disabled>Proceed to Checkout</button>
           
        </div>
    </form>

   <?php
   include 'footer.php';
   ?>

</body>
</html>