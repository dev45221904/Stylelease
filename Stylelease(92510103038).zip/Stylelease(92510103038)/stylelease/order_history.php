<?php
include 'navbar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order History</title>
    <link rel="icon" type="image/x-icon" href="stylelease_favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style/order_history.css">
</head>
<body>
    
    <div class="content">
        <h1>Order History</h1>
        
        <div class="orders-container">
            <!-- Sample Order 1 -->
            <div class="order-item">
                <div class="order-header">
                    <span class="order-number">Order #101</span>
                    <span class="order-status status-delivered">
                        Delivered
                    </span>
                </div>
                
                <img src="products images/bridal 1.jpg" 
                     alt="Red Bridal dress"
                     class="product-image">
                
                <div class="product-info">
                    <h3 class="product-title">Red Bridal Dress</h3>
                    
                    <div class="product-details">
                        <div class="detail-item">
                            <span class="detail-label">Size</span>
                            <span class="detail-value">M</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Quantity</span>
                            <span class="detail-value">1</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Order Date</span>
                            <span class="detail-value">15 Aug 2025</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Rental Days</span>
                            <span class="detail-value">3 days</span>
                        </div>
                    </div>
                    
                    <div class="rental-period">
                        <div class="detail-label">Rental Period</div>
                        <div class="detail-value">
                            16 Aug 2025 - 18 Aug 2025
                        </div>
                    </div>
                    
                    <div class="price-section">
                        <div class="total-price">₹2,850.00</div>
                        <div class="price-breakdown">
                            <div class="breakdown-item">
                                <span>Rental: ₹2,400.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span>Security: ₹800.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span>Delivery: ₹100.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span>Handling: ₹25.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span>GST (18%): ₹432.00</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="action-buttons">
                        <a href="#" class="btn btn-primary">
                            <i class="bi bi-arrow-clockwise"></i>
                            Rent Again
                        </a>
                        <a href="#" class="btn btn-success">
                            <i class="bi bi-download"></i>
                            Invoice
                        </a>
                    </div>
                </div>
            </div>

            <!-- Sample Order 2 -->
            <div class="order-item">
                <div class="order-header">
                    <span class="order-number">Order #102</span>
                    <span class="order-status status-processing">
                        Processing
                    </span>
                </div>
                
                <img src="products images/Boston Luxe.jpg" 
                     alt="Blue Business Suit"
                     class="product-image">
                
                <div class="product-info">
                    <h3 class="product-title">Blue Business Suit(Boston Luxe)</h3>
                    
                    <div class="product-details">
                        <div class="detail-item">
                            <span class="detail-label">Size</span>
                            <span class="detail-value">L</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Quantity</span>
                            <span class="detail-value">1</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Order Date</span>
                            <span class="detail-value">18 Aug 2025</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Rental Days</span>
                            <span class="detail-value">5 days</span>
                        </div>
                    </div>
                    
                    <div class="rental-period">
                        <div class="detail-label">Rental Period</div>
                        <div class="detail-value">
                            20 Aug 2025 - 24 Aug 2025
                        </div>
                    </div>
                    
                    <div class="price-section">
                        <div class="total-price">₹4,720.00</div>
                        <div class="price-breakdown">
                            <div class="breakdown-item">
                                <span>Rental: ₹4,000.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span>Security: ₹1,200.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span>Handling: ₹25.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span>GST (18%): ₹720.00</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="action-buttons">
                        <a href="cloth_detail.html?id=2" class="btn btn-primary">
                            <i class="bi bi-arrow-clockwise"></i>
                            Rent Again
                        </a>
                        <a href="generate_invoice.html?order_id=102" class="btn btn-success">
                            <i class="bi bi-download"></i>
                            Invoice
                        </a>
                    </div>
                </div>
            </div>

            <!-- Sample Order 3 -->
            <div class="order-item">
                <div class="order-header">
                    <span class="order-number">Order #103</span>
                    <span class="order-status status-cancelled">
                        Cancelled
                    </span>
                </div>
                
                <img src="products images/leh1.jpg" 
                     alt="Wedding Lehenga"
                     class="product-image">
                
                <div class="product-info">
                    <h3 class="product-title">Wedding Lehenga</h3>
                    
                    <div class="product-details">
                        <div class="detail-item">
                            <span class="detail-label">Size</span>
                            <span class="detail-value">S</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Quantity</span>
                            <span class="detail-value">1</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Order Date</span>
                            <span class="detail-value">12 Aug 2025</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Rental Days</span>
                            <span class="detail-value">2 days</span>
                        </div>
                    </div>
                    
                    <div class="rental-period">
                        <div class="detail-label">Rental Period</div>
                        <div class="detail-value">
                            14 Aug 2025 - 15 Aug 2025
                        </div>
                    </div>
                    
                    <div class="price-section">
                        <div class="total-price">₹3,540.00</div>
                        <div class="price-breakdown">
                            <div class="breakdown-item">
                                <span>Rental: ₹3,000.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span>Security: ₹1,000.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span>Delivery: ₹100.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span>Handling: ₹25.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span>GST (18%): ₹540.00</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="action-buttons">
                        <a href="cloth_detail.html?id=3" class="btn btn-primary">
                            <i class="bi bi-arrow-clockwise"></i>
                            Rent Again
                        </a>
                        <span class="btn btn-disabled">
                            <i class="bi bi-download"></i>
                            Invoice
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
include 'footer.php';
?>
</body>
</html>