<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Navbar</title>
  <link rel="icon" type="image/x-icon" href="stylelease_favicon.ico">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">

  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f7f7f7;
      margin: 0;
      padding: 0;
    }

    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px;
      background-color: white;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      height: 80px;
    }

    .logo img {
      width: 150px;
      height: auto;
    }

    .hamburger-menu {
      display: none;
      flex-direction: column;
      justify-content: space-between;
      width: 30px;
      height: 21px;
      background: none;
      border: none;
      cursor: pointer;
      padding: 0;
      z-index: 1002;
      position: relative;
    }

    .hamburger-menu span {
      width: 100%;
      height: 3px;
      background-color: #333;
    }

    .nav-container {
      flex: 1;
      display: flex;
      justify-content: flex-end;
    }

    .nav-links {
      display: flex;
      list-style: none;
      align-items: center;
      margin: 0;
      padding: 0;
    }

    .nav-links li {
      margin-right: 35px;
      position: relative;
    }

    .nav-links a {
      color: black;
      text-decoration: none;
      font-size: 18px;
      transition: color 0.3s ease;
    }

    .nav-links a:hover {
      color: #00b3b3;
    }

    .cart-icon {
      font-size: 24px;
      position: relative;
      color: black;
    }

    .cart-badge {
      position: absolute;
      top: -8px;
      right: -10px;
      background: red;
      color: white;
      font-size: 14px;
      font-weight: bold;
      border-radius: 50%;
      width: 18px;
      height: 18px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .user-dropdown {
      position: relative;
    }

    .user-icon {
      font-size: 24px;
      text-decoration: none;
      color: black;
      display: flex;
      align-items: center;
    }

    .dropdown-menu {
      display: none;
      position: absolute;
      right: 0;
      top: 100%;
      background-color: white;
      min-width: 150px;
      box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 5px;
      z-index: 1000;
      padding: 10px;
    }

    .dropdown-menu a {
      display: block;
      padding: 8px 12px;
      color: black;
      text-decoration: none;
    }

    .dropdown-menu a:hover {
      background-color: #f1f1f1;
    }

    @media (min-width: 769px) {
      .user-dropdown:hover .dropdown-menu {
        display: block;
      }
    }

    @media (max-width: 768px) {
      .navbar {
        padding: 10px;
        height: 80px;
      }

      .logo img {
        width: 60px;
        height: auto;
      }

      .hamburger-menu {
        display: flex;
        margin-right: 15px;
      }

      .nav-container {
        position: fixed;
        top: 0;
        right: -100%;
        width: 80%;
        height: 100vh;
        background-color: white;
        padding: 80px 20px 20px 20px;
        transition: right 0.3s ease-in-out;
        overflow-y: auto;
        z-index: 1001;
      }

      .nav-container.active {
        right: 0;
        box-shadow: -2px 0 5px rgba(0,0,0,0.1);
      }

      .nav-links {
        flex-direction: column;
        align-items: flex-start;
        width: 100%;
        padding-top: 20px;
      }

      .nav-links li {
        margin-right: 0;
        margin-bottom: 15px;
        width: 100%;
      }

      .nav-links a {
        font-size: 16px;
        display: block;
        padding: 10px 0;
        width: 100%;
      }

      .dropdown-menu {
        position: static;
        box-shadow: none;
        border-radius: 0;
        padding: 0;
        width: 100%;
        margin-top: 10px;
        display: none;
      }

      .dropdown-menu a {
        padding: 10px 15px;
        border-bottom: 1px solid #eee;
      }

      .dropdown-menu a:last-child {
        border-bottom: none;
      }

      .user-dropdown:hover .dropdown-menu {
        display: none;
      }
    }
  </style>
</head>

<body>

  <div class="navbar">
    <div class="logo">
      <a href="index.php"><img src="logo/logo300.png" alt="Logo"></a>
    </div>
    <button class="hamburger-menu" aria-label="Toggle menu">
      <span></span>
      <span></span>
      <span></span>
    </button>
    <div class="nav-container">
      <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="contact-us.php">Contact Us</a></li>
        <li><a href="wishlist.php">Wishlist</a></li>
        <li><a href="order_history.php">My Orders</a></li>
        <li><a href="address.php">Manage Address</a></li>
        <li>
          <a href="cart.php" class="cart-icon">
            <i class="bi bi-cart3" style="font-size: 28px;"></i>
          </a>
        </li>
        <li class="user-dropdown">
          <a href="#" class="user-icon">
            <i class="bi bi-person" style="font-size: 40px;"></i>
          </a>
          <div class="dropdown-menu">
            <a href="user-login.php" style="color: red;">Login</a>
            <a href="my_account.php" style="color: blue;">My Profile</a>
          </div>
        </li>
      </ul>
    </div>
  </div>
  <script src="js/navbar.js"></script>
</body>
</html>
