<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - StyleLease</title>
    <link rel="stylesheet" href="style/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .password-container {
            position: relative;
            width: 100%;
        }
        
        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #666;
            padding: 5px;
            background: none;
            border: none;
            z-index: 1;
        }
        
        .password-toggle:hover {
            color: #007bff;
        }
        
        input[type="password"] {
            padding-right: 35px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="left-side">
            <div class="logo-container">
                <img src="logo/logo300.png" alt="StyleLease Logo">
            </div>
        </div>
        
        <div class="right-side">
            <div class="form-container">
                <h2>User Login</h2>
                <p>New User? <a href="registration.php">Register Here</a></p>

                <form action="user-login.php" method="POST" onsubmit="return validate()">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" id="email" name="email" placeholder="Enter Your Registered Email" required>
                    </div>

                    <div class="form-group">
                        <label>Password</label>
                        <div class="password-container">
                            <input type="password" name="password" id="password" placeholder="Enter your Password" required>
                            <span class="password-toggle" onclick="togglePassword('password')">
                                <i class="fas fa-eye"></i>
                            </span>
                        </div>
                    </div>

                    <button type="submit">Login</button>
                </form>
                <p>Forgot Password? <a href="forgot_password.php">Reset Password</a></p>
                <p>Back to Home. <a href="index.php">Home</a></p>
            </div>
        </div>
    </div>

    <script src="js/user-login.js"></script>
</body>
</html>
