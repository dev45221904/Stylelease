<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style/contact-us.css">
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="content">
        <div class="contact-us-container">
            <!-- Contact Information -->
            <div class="contact-info">
                <h2>Contact Us</h2>
                <p><i class="fas fa-envelope"></i> stylelease01@gmail.com</p>
                <p><i class="fas fa-phone"></i> +91 7878360260</p>
                <p><i class="fas fa-map-marker-alt"></i> Rajkot, Gujarat</p>
            </div>

            <!-- Contact Form -->
            <div class="contact-form">
                <h2>Get in Touch</h2>
                <form method="POST" id="contactForm" onsubmit="return validate()">
                    <label for="Name">Name:</label>
                    <input type="text" id="Name" name="Name" placeholder="Enter your name">

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email">

                    <label for="contact_no">Contact No:</label>
                    <input type="tel" id="contact_no" name="contact_no" placeholder="Enter your contact number" maxlength="10">

                    <label for="message">Your Message:</label>
                    <textarea id="message" name="message" placeholder="Write your message here..." maxlength="1000"></textarea>
                    <div class="char-counter">0/1000 characters</div>

                    <button type="submit">Send Message</button>
                </form>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>

    <script src="js/contact-us.js"></script>
</body>
</html>
