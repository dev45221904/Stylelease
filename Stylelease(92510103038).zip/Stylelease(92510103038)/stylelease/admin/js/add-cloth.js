// Handle size checkbox changes
$(document).ready(function(){
    $('input[name="sizes[]"]').change(function() {
        var size = $(this).val();
        var stockInput = $('input[name="stock_' + size + '"]');
        
        if ($(this).is(':checked')) {
            stockInput.prop('disabled', false);
        } else {
            stockInput.prop('disabled', true);
            stockInput.val('0');
        }
    });
});

