// Function to toggle sidebar - only called from navbar button
function toggleSidebar() {
    document.body.classList.toggle("active-sidebar");
}

// Initialize sidebar state when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Always ensure sidebar is closed on page load
    document.body.classList.remove("active-sidebar");
    
    // Add event listeners to all sidebar links to close sidebar when clicked
    const sidebarLinks = document.querySelectorAll('.sidebar a');
    sidebarLinks.forEach(link => {
        link.addEventListener('click', function() {
            // Close sidebar when any link is clicked
            document.body.classList.remove("active-sidebar");
        });
    });
});

