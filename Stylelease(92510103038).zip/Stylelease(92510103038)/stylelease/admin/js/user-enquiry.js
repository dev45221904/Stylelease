// Static message data
const messages = {
    1: "Hi, I'm interested in renting traditional Indian wedding outfits for my upcoming wedding ceremony. Could you please provide details about availability and pricing for the month of December?",
    2: "Hello, I need to rent a designer lehenga for my sister's engagement function. Do you have options in red and gold colors? What is your rental policy?",
    3: "I'm looking for men's sherwanis and kurtas for a family wedding. We need about 5-6 outfits. Can you help with bulk rental discounts?",
    4: "Hi there! I'm planning a destination wedding and need rental outfits for the entire family. Do you provide delivery services to other cities?",
    5: "I need to rent a saree and matching accessories for a reception party. What is included in the rental package and what are the terms?",
    6: "Hello, I'm interested in your bridal collection. Could you share the catalog and rental prices for heavy bridal lehengas?",
    7: "I want to rent formal Indian wear for a corporate Diwali celebration. Do you have options suitable for office parties?",
    8: "Hi, I need urgent rental for a sangeet ceremony this weekend. What is your express service policy and additional charges?"
};

// Show message
function showMessage(id) {
    var modal = document.getElementById("messageModal");
    var message = messages[id] || "Message not found";
    document.getElementById('messageContent').textContent = message;
    modal.style.display = "block";
}

// Initialize modal and event handlers
document.addEventListener('DOMContentLoaded', function(){
    // Modal refs
    var modal = document.getElementById("messageModal");
    var span = document.getElementsByClassName("close")[0];

    // Close modal
    if(span) {
        span.onclick = function() { modal.style.display = "none"; };
    }
    window.onclick = function(event) { 
        if (event.target == modal) { 
            modal.style.display = "none"; 
        } 
    };

    // === Delete validation (taught style) – no HTML changes needed ===
    var delForms = document.querySelectorAll('form[action="delete-f/delete-enquiry.php"]');
    for(var i=0; i<delForms.length; i++){
        delForms[i].addEventListener('submit', function(e){
            // taught-style validation
            var idInput = this.querySelector('input[name="Id"]');
            var val = idInput ? idInput.value : "";

            if(val == ""){
                alert("Invalid enquiry id");
                e.preventDefault();
                return false;
            }
            // confirm
            var ok = confirm("Are you sure you want to delete this enquiry?");
            if(!ok){
                e.preventDefault();
                return false;
            }
            // allow submit
            return true;
        });
    }
});

