<?php
include 'navbar-dashboard.php';
include 'sidebar.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New Orders</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="style/new_orders.css">
</head>
<body>
    <div class="main-content">
        <h1>New Orders</h1>
        <p><a href="dashboard.php" class="dashboard-link">Dashboard</a> / Manage New Orders</p>

        <div class="user-details">
            <h3>Order Details</h3>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer Name</th>
                        <th>Email</th>
                        <th>Contact</th>
                        <th>Quantity</th>
                        <th>Size</th>
                        <th>Amount</th>
                        <th>Order Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1001</td>
                        <td>John Smith</td>
                        <td>john.smith@email.com</td>
                        <td>+91 9876543210</td>
                        <td>2</td>
                        <td>L</td>
                        <td>₹2,850.00</td>
                        <td>2025-09-27</td>
                        <td>Pending</td>
                        <td class="action-buttons">
                            <button class="view-btn" onclick="window.location.href='view_order_details.php?id=1001'">View Details</button>
                            <form action="send_new_order_mail.php" method="POST" style="display: inline;">
                                <input type="hidden" name="order_id" value="1001">
                                <input type="hidden" name="user_email" value="john.smith@email.com">
                                <input type="hidden" name="username" value="John Smith">
                                <input type="hidden" name="contact_no" value="+91 9876543210">
                                <button type="submit" class="send-mail-btn">Send Mail</button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>1002</td>
                        <td>Priya Sharma</td>
                        <td>priya.sharma@email.com</td>
                        <td>+91 8765432109</td>
                        <td>1</td>
                        <td>M</td>
                        <td>₹1,950.00</td>
                        <td>2025-09-26</td>
                        <td>Pending</td>
                        <td class="action-buttons">
                            <button class="view-btn" onclick="window.location.href='view_order_details.php?id=1002'">View Details</button>
                            <form action="send_new_order_mail.php" method="POST" style="display: inline;">
                                <input type="hidden" name="order_id" value="1002">
                                <input type="hidden" name="user_email" value="priya.sharma@email.com">
                                <input type="hidden" name="username" value="Priya Sharma">
                                <input type="hidden" name="contact_no" value="+91 8765432109">
                                <button type="submit" class="send-mail-btn">Send Mail</button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>1003</td>
                        <td>Rajesh Kumar</td>
                        <td>rajesh.kumar@email.com</td>
                        <td>+91 7654321098</td>
                        <td>3</td>
                        <td>XL</td>
                        <td>₹4,275.00</td>
                        <td>2025-09-26</td>
                        <td>Pending</td>
                        <td class="action-buttons">
                            <button class="view-btn" onclick="window.location.href='view_order_details.php?id=1003'">View Details</button>
                            <form action="send_new_order_mail.php" method="POST" style="display: inline;">
                                <input type="hidden" name="order_id" value="1003">
                                <input type="hidden" name="user_email" value="rajesh.kumar@email.com">
                                <input type="hidden" name="username" value="Rajesh Kumar">
                                <input type="hidden" name="contact_no" value="+91 7654321098">
                                <button type="submit" class="send-mail-btn">Send Mail</button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>1004</td>
                        <td>Anita Patel</td>
                        <td>anita.patel@email.com</td>
                        <td>+91 6543210987</td>
                        <td>1</td>
                        <td>S</td>
                        <td>₹1,750.00</td>
                        <td>2025-09-25</td>
                        <td>Pending</td>
                        <td class="action-buttons">
                            <button class="view-btn" onclick="window.location.href='view_order_details.php?id=1004'">View Details</button>
                            <form action="send_new_order_mail.php" method="POST" style="display: inline;">
                                <input type="hidden" name="order_id" value="1004">
                                <input type="hidden" name="user_email" value="anita.patel@email.com">
                                <input type="hidden" name="username" value="Anita Patel">
                                <input type="hidden" name="contact_no" value="+91 6543210987">
                                <button type="submit" class="send-mail-btn">Send Mail</button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>1005</td>
                        <td>Vikram Singh</td>
                        <td>vikram.singh@email.com</td>
                        <td>+91 5432109876</td>
                        <td>2</td>
                        <td>L</td>
                        <td>₹3,125.00</td>
                        <td>2025-09-25</td>
                        <td>Pending</td>
                        <td class="action-buttons">
                            <button class="view-btn" onclick="window.location.href='view_order_details.php?id=1005'">View Details</button>
                            <form action="send_new_order_mail.php" method="POST" style="display: inline;">
                                <input type="hidden" name="order_id" value="1005">
                                <input type="hidden" name="user_email" value="vikram.singh@email.com">
                                <input type="hidden" name="username" value="Vikram Singh">
                                <input type="hidden" name="contact_no" value="+91 5432109876">
                                <button type="submit" class="send-mail-btn">Send Mail</button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>1006</td>
                        <td>Meera Gupta</td>
                        <td>meera.gupta@email.com</td>
                        <td>+91 4321098765</td>
                        <td>1</td>
                        <td>M</td>
                        <td>₹2,100.00</td>
                        <td>2025-09-24</td>
                        <td>Pending</td>
                        <td class="action-buttons">
                            <button class="view-btn" onclick="window.location.href='view_order_details.php?id=1006'">View Details</button>
                            <form action="send_new_order_mail.php" method="POST" style="display: inline;">
                                <input type="hidden" name="order_id" value="1006">
                                <input type="hidden" name="user_email" value="meera.gupta@email.com">
                                <input type="hidden" name="username" value="Meera Gupta">
                                <input type="hidden" name="contact_no" value="+91 4321098765">
                                <button type="submit" class="send-mail-btn">Send Mail</button>
                            </form>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>