<?php
include 'navbar-dashboard.php';
include 'sidebar.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage User Enquiries</title>
    <style>
        body {
            display: flex;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f7fafc;
            margin: 0;
            min-height: 100vh;
        }
        .main-content {
            flex-grow: 1;
            padding: 1.5rem;
            margin-left: 0;
            margin-top: 40px;
            transition: all 0.3s ease;
        }
        body.active-sidebar .main-content { margin-left: 250px; }
        .user-details {
            background: #fff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,.1);
            padding: 20px; margin-top: 20px; overflow-x: auto;
        }
        .user-details table { width: 100%; border-collapse: collapse; margin-top: 15px; min-width: 1200px; }
        .user-details th {
            background-color: #f8f9fa; padding: 12px; text-align: left; font-weight: 600; color: #333;
            border-bottom: 2px solid #dee2e6; white-space: nowrap;
        }
        .user-details td { padding: 12px; border-bottom: 1px solid #dee2e6; color: #555; }
        .user-details tr:hover { background-color: #f8f9fa; }
        h1 { color: #333; margin-bottom: 1rem; }
        .dashboard-link { color: #007bff; text-decoration: none; font-size: 14px; }
        .dashboard-link:hover { text-decoration: underline; }
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%;
                 background-color: rgba(0,0,0,0.5); }
        .modal-content {
            background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888;
            width: 80%; max-width: 500px; border-radius: 5px; position: relative;
        }
        .close { color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer; }
        .close:hover { color: black; }
        .show-message-btn {
            background-color: #4CAF50; color: white; border: none; padding: 6px 12px; border-radius: 4px;
            cursor: pointer; font-size: 14px; transition: background-color .2s;
        }
        .show-message-btn:hover { background-color: #45a049; }
        .message-content { margin-top: 20px; white-space: pre-wrap; word-wrap: break-word; }
        .delete-btn {
            background-color: #dc3545; color: white; border: none; padding: 6px 12px; border-radius: 4px;
            cursor: pointer; font-size: 14px; transition: background-color .2s;
        }
        .delete-btn:hover { background-color: #c82333; }
        .action-buttons { display: flex; gap: 8px; align-items: center; white-space: nowrap; }
    </style>
</head>
<body>
    <div class="main-content">
        <h1>Manage User Enquires</h1>
        <p><a href="dashboard.php" class="dashboard-link">Dashboard</a> / Manage User Enquires</p>

        <div class="user-details">
            <h3>User Enquires</h3>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Contact-no</th>
                        <th>Message</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Rahul Sharma</td>
                        <td>rahul.sharma@email.com</td>
                        <td>+91 9876543210</td>
                        <td><button class='show-message-btn' onclick='showMessage(1)'>Show Message</button></td>
                        <td>
                            <form action='delete-f/delete-enquiry.php' method='POST'>
                                <input type='hidden' name='Id' value='1'>
                                <button type='submit' class='delete-btn'>Delete Enquiry</button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>Priya Patel</td>
                        <td>priya.patel@email.com</td>
                        <td>+91 8765432109</td>
                        <td><button class='show-message-btn' onclick='showMessage(2)'>Show Message</button></td>
                        <td>
                            <form action='delete-f/delete-enquiry.php' method='POST'>
                                <input type='hidden' name='Id' value='2'>
                                <button type='submit' class='delete-btn'>Delete Enquiry</button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>Amit Kumar</td>
                        <td>amit.kumar@email.com</td>
                        <td>+91 7654321098</td>
                        <td><button class='show-message-btn' onclick='showMessage(3)'>Show Message</button></td>
                        <td>
                            <form action='delete-f/delete-enquiry.php' method='POST'>
                                <input type='hidden' name='Id' value='3'>
                                <button type='submit' class='delete-btn'>Delete Enquiry</button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>Sneha Gupta</td>
                        <td>sneha.gupta@email.com</td>
                        <td>+91 6543210987</td>
                        <td><button class='show-message-btn' onclick='showMessage(4)'>Show Message</button></td>
                        <td>
                            <form action='delete-f/delete-enquiry.php' method='POST'>
                                <input type='hidden' name='Id' value='4'>
                                <button type='submit' class='delete-btn'>Delete Enquiry</button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>Vikram Singh</td>
                        <td>vikram.singh@email.com</td>
                        <td>+91 5432109876</td>
                        <td><button class='show-message-btn' onclick='showMessage(5)'>Show Message</button></td>
                        <td>
                            <form action='delete-f/delete-enquiry.php' method='POST'>
                                <input type='hidden' name='Id' value='5'>
                                <button type='submit' class='delete-btn'>Delete Enquiry</button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>Kavya Nair</td>
                        <td>kavya.nair@email.com</td>
                        <td>+91 4321098765</td>
                        <td><button class='show-message-btn' onclick='showMessage(6)'>Show Message</button></td>
                        <td>
                            <form action='delete-f/delete-enquiry.php' method='POST'>
                                <input type='hidden' name='Id' value='6'>
                                <button type='submit' class='delete-btn'>Delete Enquiry</button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>Arjun Reddy</td>
                        <td>arjun.reddy@email.com</td>
                        <td>+91 3210987654</td>
                        <td><button class='show-message-btn' onclick='showMessage(7)'>Show Message</button></td>
                        <td>
                            <form action='delete-f/delete-enquiry.php' method='POST'>
                                <input type='hidden' name='Id' value='7'>
                                <button type='submit' class='delete-btn'>Delete Enquiry</button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td>Meera Agarwal</td>
                        <td>meera.agarwal@email.com</td>
                        <td>+91 2109876543</td>
                        <td><button class='show-message-btn' onclick='showMessage(8)'>Show Message</button></td>
                        <td>
                            <form action='delete-f/delete-enquiry.php' method='POST'>
                                <input type='hidden' name='Id' value='8'>
                                <button type='submit' class='delete-btn'>Delete Enquiry</button>
                            </form>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal for displaying message -->
    <div id="messageModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Message Details</h2>
            <div id="messageContent" class="message-content"></div>
        </div>
    </div>

    <script src="js/user-enquiry.js"></script>
</body>
</html>
