<?php
include_once('navbar-dashboard.php');
include_once('sidebar.php');    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category & Sub-Category</title>
    <link rel="stylesheet" href="styles/add-category-subcategory.css">
    <link rel="stylesheet" href="style/category.css">
</head>
<body>
    <div class="main-content">
        <div class="container">
            <!-- Category Section -->
            <section class="category-section">
                <h2>Add Category</h2>
                <form action="Add_category_subcategory.php" method="POST" class="add-category-form">
                    <label for="category_name">Category Name</label>
                    <input type="text" id="category_name" name="category_name" required>
                    <button type="submit">Add Category</button>
                </form>
            </section>

            <hr class="section-divider">

            <!-- Subcategory Section -->
            <section class="subcategory-section">
                <h2>Add Sub-Category</h2>
                <form method="POST" action="Add_category_subcategory.php" class="add-subcategory-form">
                    <label for="CategoryId">Category Name:</label>
                    <select name="CategoryId" id="CategoryId" required>
                        <option value="">Select Category</option>
                    </select>
                    <label for="SubCategoryName">Sub-Category Name:</label>
                    <input type="text" name="SubCategoryName" id="SubCategoryName" required>
                    <button type="submit">Add Sub-Category</button>
                </form>
            </section>
        </div>
    </div>
</body>
</html> 