<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        .sidebar {
            height: calc(100vh - 40px);
            width: 250px;
            position: fixed;
            top: 40px;
            left: -250px;
            background-color: white;
            color: #333;
            transition: left 0.3s;
            overflow-y: auto;
            scrollbar-width: thin;
            scrollbar-color: #ccc white;
            padding-top: 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        
        /* Webkit scrollbar styling */
        .sidebar::-webkit-scrollbar {
            width: 6px;
        }
        
        .sidebar::-webkit-scrollbar-track {
            background: white;
        }
        
        .sidebar::-webkit-scrollbar-thumb {
            background-color: #ccc;
            border-radius: 3px;
        }
        
        .sidebar a {
            padding: 8px 15px;
            text-decoration: none;
            font-size: 16px;
            color: #666;
            display: block;
            transition: all 0.3s;
            margin: 0;
        }
        
        .sidebar a:hover {
            background-color: #f5f5f5;
            color: #333;
        }
        
        .logo-container {
            padding: 10px;
            background-color: white;
            border-bottom: 1px solid #eee;
            text-align: center;
        }

        .logo-container img {
            width: 160px;
            height: auto;
            display: block;
            margin: 0 auto;
        }

        .sidebar h3 {
            color: #333;
            padding: 8px 15px;
            margin: 0;
            font-size: 16px;
            border-top: 1px solid #eee;
            background-color: white;
            font-weight: 600;
        }
        
        .main-content {
            transition: margin-left 0.3s;
            margin-left: 0;
            padding-top: 40px;
        }
        
        body.active-sidebar .sidebar {
            left: 0; 
        }
        
        body.active-sidebar .main-content {
            margin-left: 250px; 
        }

        body {
            margin: 0;
            padding: 0;
        }
    </style>
</head>
<body>
    <div id="sidebar" class="sidebar">
        <div class="logo-container">
            <img src="logo/logo300.png" alt="StyleLease Logo">
        </div>
        <h3><a href="dashboard.php">Dashboard</a></h3>
        
        <h3>Categories</h3>
        <a href="Add_category_subcategory.php">Add Categories</a>
      
        <h3>Rental Cloths</h3>
        <a href="add_cloth.php">Add Product</a>
        <h3>Order Management</h3>
        <a href="new_orders.php">New Orders</a>
        <h3>Users</h3>
        <a href="registered-users.php">Registered Users</a>
        <h3>User-Enquiries</h3>
        <a href="user-enquiry.php">User-Enquires</a>
    </div>
    
    <script src="js/sidebar.js"></script>
</body>
</html>
