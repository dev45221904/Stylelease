<?php
include_once('navbar-dashboard.php');
include_once('sidebar.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Cloth</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="style/add_cloth.css">
</head>
<body>
    <div class="main-content">
        <div class="container">
            <h1>Add New Product</h1>

            <!-- ✅ added onsubmit to call taught-style validator -->
            <form method="post" enctype="multipart/form-data" onsubmit="return validate()">
                <div class="form-grid">
                    <div class="form-section">
                        <div class="form-group">
                            <label for="gender">Gender:</label>
                            <select name="gender" id="gender" required>
                                <option value="">Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="title">Title:</label>
                            <input type="text" name="title" id="title" required>
                        </div>

                        <div class="form-group">
                            <label for="price">Price Per Day:</label>
                            <input type="number" name="price" id="price" required>
                        </div>

                        <div class="form-group">
                            <label for="security_amount">Security Amount:</label>
                            <input type="number" name="security_amount" id="security_amount" required>
                        </div>
                    </div>

                    <div class="form-section">
                        <div class="form-group">
                            <label for="category">Category:</label>
                            <select name="category" id="category" required>
                                <option value="">Select Category</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="subcategory">Subcategory:</label>
                            <select name="subcategory" id="subcategory" required>
                                <option value="">Select Subcategory</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="productDescription">Product Description:</label>
                            <textarea name="productDescription" id="productDescription" rows="4" required></textarea>
                        </div>
                    </div>
                </div>
                
                <!-- Size and Stock Manage -->
                <div class="form-section">
                    <label>Size and Stock:</label>
                    <div class="size-stock-container">
                        <div class='size-stock-group'>
                            <input type='checkbox' name='sizes[]' value='S' id='size_S' class='size-checkbox'>
                            <label for='size_S'>S</label>
                            <div class='stock-input-group'>
                                <label>Stock:</label>
                                <input type='number' name='stock_S' min='0' value='0' disabled class='stock-input'>
                            </div>
                        </div>
                        <div class='size-stock-group'>
                            <input type='checkbox' name='sizes[]' value='M' id='size_M' class='size-checkbox'>
                            <label for='size_M'>M</label>
                            <div class='stock-input-group'>
                                <label>Stock:</label>
                                <input type='number' name='stock_M' min='0' value='0' disabled class='stock-input'>
                            </div>
                        </div>
                        <div class='size-stock-group'>
                            <input type='checkbox' name='sizes[]' value='L' id='size_L' class='size-checkbox'>
                            <label for='size_L'>L</label>
                            <div class='stock-input-group'>
                                <label>Stock:</label>
                                <input type='number' name='stock_L' min='0' value='0' disabled class='stock-input'>
                            </div>
                        </div>
                        <div class='size-stock-group'>
                            <input type='checkbox' name='sizes[]' value='XL' id='size_XL' class='size-checkbox'>
                            <label for='size_XL'>XL</label>
                            <div class='stock-input-group'>
                                <label>Stock:</label>
                                <input type='number' name='stock_XL' min='0' value='0' disabled class='stock-input'>
                            </div>
                        </div>
                        <div class='size-stock-group'>
                            <input type='checkbox' name='sizes[]' value='XXL' id='size_XXL' class='size-checkbox'>
                            <label for='size_XXL'>XXL</label>
                            <div class='stock-input-group'>
                                <label>Stock:</label>
                                <input type='number' name='stock_XXL' min='0' value='0' disabled class='stock-input'>
                            </div>
                        </div>
                        <div class='size-stock-group'>
                            <input type='checkbox' name='sizes[]' value='XXXL' id='size_XXXL' class='size-checkbox'>
                            <label for='size_XXXL'>XXXL</label>
                            <div class='stock-input-group'>
                                <label>Stock:</label>
                                <input type='number' name='stock_XXXL' min='0' value='0' disabled class='stock-input'>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <label>Product Images:</label>
                    <div class="image-upload">
                        <div class="image-upload-group">
                            <label for="image">Main Image</label>
                            <input type="file" name="image" id="image" accept="image/*" required>
                        </div>
                        <div class="image-upload-group">
                            <label for="image2">Second Image</label>
                            <input type="file" name="image2" id="image2" accept="image/*" required>
                        </div>
                        <div class="image-upload-group">
                            <label for="image3">Third Image</label>
                            <input type="file" name="image3" id="image3" accept="image/*" required>
                        </div>
                    </div>
                </div>

                <button type="submit" class="submit-btn">Add Product</button>
            </form>
        </div>
    </div>

    <script src="js/add-cloth.js"></script>
</body>
</html>
