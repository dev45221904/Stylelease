<?php
include 'navbar-dashboard.php';
include 'sidebar.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Registered Users</title>
    <style>
        body {
            display: flex;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f7fafc;
            margin: 0;
            min-height: 100vh;
        }

        .main-content {
            flex-grow: 1;
            padding: 1.5rem;
            margin-left: 0;
            margin-top: 40px;
            transition: all 0.3s ease;
        }

        body.active-sidebar .main-content {
            margin-left: 250px;
        }

        .user-details {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 20px;
            overflow-x: auto;
        }

        .user-details table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            min-width: 1200px;
        }

        .user-details th {
            background-color: #f8f9fa;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #333;
            border-bottom: 2px solid #dee2e6;
            white-space: nowrap;
        }

        .user-details td {
            padding: 12px;
            border-bottom: 1px solid #dee2e6;
            color: #555;
        }

        .user-details tr:hover {
            background-color: #f8f9fa;
        }

        h1 {
            color: #333;
            margin-bottom: 1rem;
        }

        .dashboard-link {
            color: #007bff;
            text-decoration: none;
            font-size: 14px;
        }

        .dashboard-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="main-content">
        <h1>Manage Registered Users</h1>
        <p><a href="dashboard.php" class="dashboard-link">Dashboard</a> / Manage Registered Users</p>

        <div class="user-details">
            <h3>Users Details</h3>
            <table>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email ID</th>
                        <th>Gender</th>
                        <th>Contact No.</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>101</td>
                        <td>Amit Sharma</td>
                        <td>amit.sharma@email.com</td>
                        <td>Male</td>
                        <td>+91 9876543210</td>
                    </tr>
                    <tr>
                        <td>102</td>
                        <td>Priya Singh</td>
                        <td>priya.singh@email.com</td>
                        <td>Female</td>
                        <td>+91 8765432109</td>
                    </tr>
                    <tr>
                        <td>103</td>
                        <td>Rajesh Kumar</td>
                        <td>rajesh.kumar@email.com</td>
                        <td>Male</td>
                        <td>+91 7654321098</td>
                    </tr>
                    <tr>
                        <td>104</td>
                        <td>Anita Patel</td>
                        <td>anita.patel@email.com</td>
                        <td>Female</td>
                        <td>+91 6543210987</td>
                    </tr>
                    <tr>
                        <td>105</td>
                        <td>Vikram Gupta</td>
                        <td>vikram.gupta@email.com</td>
                        <td>Male</td>
                        <td>+91 5432109876</td>
                    </tr>
                    <tr>
                        <td>106</td>
                        <td>Meera Agarwal</td>
                        <td>meera.agarwal@email.com</td>
                        <td>Female</td>
                        <td>+91 4321098765</td>
                    </tr>
                    <tr>
                        <td>107</td>
                        <td>Arjun Reddy</td>
                        <td>arjun.reddy@email.com</td>
                        <td>Male</td>
                        <td>+91 3210987654</td>
                    </tr>
                    <tr>
                        <td>108</td>
                        <td>Kavya Nair</td>
                        <td>kavya.nair@email.com</td>
                        <td>Female</td>
                        <td>+91 2109876543</td>
                    </tr>
                    <tr>
                        <td>109</td>
                        <td>Deepak Joshi</td>
                        <td>deepak.joshi@email.com</td>
                        <td>Male</td>
                        <td>+91 1098765432</td>
                    </tr>
                    <tr>
                        <td>110</td>
                        <td>Riya Mehta</td>
                        <td>riya.mehta@email.com</td>
                        <td>Female</td>
                        <td>+91 9087654321</td>
                    </tr>
                    <tr>
                        <td>111</td>
                        <td>Sanjay Yadav</td>
                        <td>sanjay.yadav@email.com</td>
                        <td>Male</td>
                        <td>+91 8976543210</td>
                    </tr>
                    <tr>
                        <td>112</td>
                        <td>Sneha Verma</td>
                        <td>sneha.verma@email.com</td>
                        <td>Female</td>
                        <td>+91 7865432109</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>