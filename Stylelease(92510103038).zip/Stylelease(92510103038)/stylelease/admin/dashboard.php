
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style/dashboard.css" >
     <style>
       
     </style>
</head>
<body>
    <div class="main-content">
        <?php include_once('navbar-dashboard.php'); ?>
        <div class="dashboard">
            <div class="card" onclick="window.location.href='new_orders.php'">
                <h3>New Orders</h3>
                <p id="new-orders-count">10</p>
            </div>
            <div class="card" onclick="window.location.href='processing_orders.php'">
                <h3>Processing Orders</h3>
                <p id="processing-orders-count">10</p>
            </div>
            <div class="card" onclick="window.location.href='shipped_orders.php'">
                <h3>Shipped Orders</h3>
                <p id="shipped-orders-count">10</p>
            </div>
            <div class="card" onclick="window.location.href='out_for_delivery_orders.php'">
                <h3>Out For Delivery Orders</h3>
                <p id="out-for-delivery-orders-count">10</p>
            </div>
            <div class="card" onclick="window.location.href='delivered_orders.php'">
                <h3>Delivered Orders</h3>
                <p id="delivered-orders-count">10</p>
            </div>
            <div class="card" onclick="window.location.href='returned_orders.php'">
                <h3>Returned Orders</h3>
                <p id="Returned-orders-count">10</p>
            </div>
            <div class="card" onclick="window.location.href='cancelled_orders.php'">
                <h3>Cancelled Orders</h3>
                <p id="cancelled-orders-count">10</p>
            </div>
            <div class="card" onclick="window.location.href='listed-rentals.php'">
                <h3>Listed-Rentals</h3>
                <p>10</p>
            </div>
            <div class="card" onclick="window.location.href='registered-users.php'">
                <h3>Registered Users</h3>
                <p>10</p>
            </div>
            <div class="card" onclick="window.location.href='listed-categories.php'">
                <h3>Listed Categories</h3>
                <p>10</p>
            </div>
            <div class="card" onclick="window.location.href='listed-subcategories.php'">
                <h3>Listed Subcategories</h3>
                <p>10</p>
            </div>
        </div>
    </div>

    <?php include 'sidebar.php'; ?>
</body>
</html>
