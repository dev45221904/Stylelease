<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style/footer.css">
</head>
<body>
    <div class="footer">
        <div class="footer-content">
            <div class="footer-logo">
                <img src="logo/logo300.png" alt="StyleLease Logo">
                <p>Your premier destination for fashion rentals.</p>
            </div>
            
            <div class="footer-links">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="contact-us.php">Contact Us</a></li>
                    <li><a href="wishlist.php">Wishlist</a></li>
                    <li><a href="order_history.php">My Orders</a></li>
                    <li><a href="address.php">Manage Address</a></li>
                </ul>
            </div>
            
            <div class="footer-contact">
                <h3>Contact Info</h3>
                <p><i class="bi bi-geo-alt"></i> 123 Fashion Street, Mumbai, India</p>
                <p><i class="bi bi-telephone"></i> +91 123 456 7890</p>
                <p><i class="bi bi-envelope"></i> info@stylelease.com</p>
                <p><i class="bi bi-clock"></i> Mon - Sat: 10:00 AM - 8:00 PM</p>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2025 StyleLease. All rights reserved</p>
        </div>
    </div>

    
</body>
</html>
    


