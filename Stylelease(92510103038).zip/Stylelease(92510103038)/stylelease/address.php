<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Addresses - StyleLease</title>
    <link rel="stylesheet" href="style/address.css">
    <style>
        /* Saved Addresses Styles */
        .saved-addresses-section h2 {
            font-size: 1.8rem;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 30px;
        }

        .address-item {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            border: 1px solid #e9ecef;
        }

        .address-item h3 {
            color: #007bff;
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .address-details {
            margin-bottom: 15px;
        }

        .address-details p {
            margin: 5px 0;
            color: #495057;
            line-height: 1.5;
        }

        .address-details p strong {
            color: #2c3e50;
        }

        .address-actions {
            display: flex;
            gap: 10px;
        }

        .btn-success {
            background-color: #28a745;
            color: white;
            padding: 8px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
        }

        .btn-success:hover {
            background-color: #218838;
            color: white;
        }

        .btn-danger {
            background-color: #dc3545;
            color: white;
            padding: 8px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="content">
        <div class="container">
            <h2>Manage Addresses</h2>
            <form method="POST">
                <input type="hidden" name="address_id" id="address_id">
                <div class="row">
                    <div class="col-md-12">
                        <h3>Address</h3>
                        <div class="form-group">
                            <label for="address">Address</label>
                            <textarea name="address" id="address" placeholder="Enter Address" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="country">Country</label>
                            <input type="text" name="country" id="country" placeholder="Enter Country" required>
                        </div>
                        <div class="form-group">
                            <label for="state">State</label>
                            <input type="text" name="state" id="state" placeholder="Enter State" required>
                        </div>
                        <div class="form-group">
                            <label for="city">City</label>
                            <input type="text" name="city" id="city" placeholder="Enter City" required>
                        </div>
                        <div class="form-group">
                            <label for="zip_code">Zip Code</label>
                            <input type="text" 
                                   name="zip_code" 
                                   id="zip_code" 
                                   placeholder="Enter Zip Code" 
                                   required 
                                   pattern="[0-9]*"
                                   oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                        </div>
                    </div>
                </div>
                <button type="submit">Save Address</button>
            </form>
        </div>
    <!-- Saved Addresses -->
        <div class="saved-addresses-section">
            <h2>Saved Addresses</h2>
            
            <!-- Address 1 -->
            <div class="address-item">
                <h3>Address</h3>
                <div class="address-details">
                    <p><strong>Address:</strong>St.45 Ninth Avenue</p>
                    <p><strong>City:</strong> Manhatten</p>
                    <p><strong>State:</strong>New York</p>
                    <p><strong>Country:</strong> America</p>
                    <p><strong>Zip Code:</strong> 394215</p>
                </div>
                <div class="address-actions">
                    <button class="btn-success">Update</button>
                    <button class="btn-danger">Delete</button>
                </div>
            </div>
           
        </div>
    

    <?php include 'footer.php'; ?>

    <script src="js/address.js"></script>
</body>
</html>
