<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration - StyleLease</title>
    <link rel="stylesheet" href="style/registration.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .password-container { position: relative; width: 100%; }
        .password-toggle { position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer; color: #666; padding: 5px; background: none; border: none; z-index: 1; }
        .password-toggle:hover { color: #007bff; }
        input[type="password"] { padding-right: 35px; }
        select {
            width: 100%; padding: 0.8rem; border: 1px solid #ddd; border-radius: 8px; font-size: 1rem;
            transition: border-color 0.3s ease; background-color: white; cursor: pointer; appearance: none;
            -webkit-appearance: none; -moz-appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat; background-position: right 1rem center; background-size: 1em;
        }
        select:focus { outline: none; border-color: #007bff; }
        .err { color:#d00; font-size:.9rem; display:block; margin-top:.35rem; min-height:1.1em; }
        .hint { color:#666; font-size:.9rem; display:block; margin-top:.5rem; }
    </style>
</head>
<body>
    <div class="container">
        <div class="left-side">
            <div class="logo-container">
                <img src="logo/logo300.png" alt="StyleLease Logo">
            </div>
        </div>
        
        <div class="right-side">
            <div class="form-container">
                <h2>Create an Account</h2>
                <p>Already a user? <a href="user-login.php">Login</a></p>
                
                <form method="POST" id="registrationForm" onsubmit="return validate()">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" placeholder="Enter Your Name">
                        <span id="usr" class="err"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="Enter Your Email">
                        <span id="eml" class="err"></span>
                    </div>

                    <div class="form-group">
                        <label for="contact_no">Contact No.</label>
                        <input type="text" 
                               name="contact_no" 
                               id="contact_no"
                               placeholder="Enter Your Contact No."
                               maxlength="10"
                               oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0,10)">
                        <span id="nm" class="err"></span>
                    </div>
                    
                    <div class="form-group">
                        <label for="gender">Gender</label>
                        <select id="gender" name="gender">
                            <option value="">Select Gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                        <span id="gnd" class="err"></span>
                    </div>

                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="password-container">
                            <input type="password" name="password" id="password" placeholder="Password">
                            <span class="password-toggle" onclick="togglePassword('password')">
                                <i class="fas fa-eye"></i>
                            </span>
                        </div>
                        <small class="hint">
                            Password must be 8-10 characters long, include 1 uppercase, 1 number, and 1 special character
                        </small>
                        <span id="pas" class="err"></span>
                    </div>

                    <button type="submit" id="registerBtn">
                        <div class="loading-spinner"></div>
                        <span class="button-text">Register</span>
                        <span class="loading-text">Registering...</span>
                    </button>
                </form>

                <p>Back to Home. <a href="index.php">Home</a></p>
            </div>
        </div>
    </div>

    <script src="js/registration.js"></script>
</body>
</html>
