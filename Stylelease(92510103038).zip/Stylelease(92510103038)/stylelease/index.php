<?php
include 'navbar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>StyleLease</title>
  <link rel="icon" type="image/x-icon" href="stylelease_favicon.ico">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="style/style.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
<section class="product-grid">
  <h2>Rental Products</h2>

  <!-- Filters -->
  <div class="filters">
    <form id="filterForm" class="filter-form" onsubmit="return validateFilter()">
      <div class="filter-group">
        <label for="search">Search:</label>
        <input type="text" id="search" name="search" placeholder="Search products..." class="search-input">
        <span id="srch" class="text-danger"></span>
      </div>

      <div class="filter-group">
        <label for="gender">Gender:</label>
        <select id="gender" name="gender">
          <option value="">All</option>
          <option value="Male">Men</option>
          <option value="Female">Women</option>
        </select>
      </div>

      <div class="filter-group">
        <label for="category">Category:</label>
        <select id="category" name="category">
          <option value="">All Categories</option>
          <option value="1">Men Suits</option>
          <option value="2">Men Ethnic</option>
          <option value="3">Ethnic Wear Women</option>
          <option value="4">Western Women</option>
        </select>
      </div>
    </form>
  </div>

  <!-- Products Grid -->
  <div class="products">
    <div class="product">
      <img src="products images/maroon 1.jpeg" alt="Blue Cotton T-Shirt">
      <div class="details">
        <h3>Blazer</h3>
        <p class="category">Men Suits</p>
        <p>Rs. 350.00 per day</p>
      </div>
      <a href="cloth_detail.html?id=1" class="view-btn">View</a>
    </div>

    <div class="product">
      <img src="products images/Boston Luxe.jpg" alt="Red Evening Dress">
      <div class="details">
        <h3>Boston Luxe</h3>
        <p class="category">Men Suits</p>
        <p>Rs. 800.00 per day</p>
      </div>
      <a href="cloth_detail.html?id=2" class="view-btn">View</a>
    </div>

    <div class="product">
      <img src="products images/TShervani2.jpg" alt="Green Leather Jacket">
      <div class="details">
        <h3>Sherwani</h3>
        <p class="category">Men Ethnic</p>
        <p>Rs. 1200.00 per day</p>
      </div>
      <a href="cloth_detail.html?id=3" class="view-btn">View</a>
    </div>

    <div class="product">
      <img src="products images/shervani 1.jpg" alt="Yellow Summer Skirt">
      <div class="details">
        <h3>Off-White Embroidered Sherwani</h3>
        <p class="category">Men Ethnic</p>
        <p>Rs. 450.00 per day</p>
      </div>
      <a href="cloth_detail.html?id=4" class="view-btn">View</a>
    </div>

    <div class="product">
      <img src="products images/leh1.jpg" alt="Purple Formal Shirt">
      <div class="details">
        <h3>Lehenga</h3>
        <p class="category">Ethnic Wear Women</p>
        <p>Rs. 500.00 per day</p>
      </div>
      <a href="cloth_detail.html?id=5" class="view-btn">View</a>
    </div>

    <div class="product">
      <img src="products images/wes 1.jpg" alt="Orange Silk Blouse">
      <div class="details">
        <h3>Coral Asymmetric Kurta Set</h3>
        <p class="category">Western Women</p>
        <p>Rs. 600.00 per day</p>
      </div>
      <a href="cloth_detail.html?id=6" class="view-btn">View</a>
    </div>
  </div>
</section>

<script src="js/index.js"></script>

<?php
include 'footer.php';
?>
</body>
</html>
